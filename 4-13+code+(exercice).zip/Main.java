package com.mhz;

public class Main {


    public static void main(String[] args) {

        // TODO ******* ArrayList *******

        // Créez une ArrayList de String "colors1",
        // ajoutez 3 couleurs (black, Red, Yellow),
        // affichez "colors1"

        // Affichez chaque couleur par ligne

        // Ajoutez une nouvelle couleur (Blue) au début de "colors1"
        // affichez "colors1"

        // Affichez la deuxième couleur

        // Remplacez la deuxième couleur par (Purple)
        // affichez "colors1"

        // Supprimez la troisième couleur
        // affichez "colors1"

        // Vérifiez si "colors1" contient la couleur "Black"

        // Triez "colors1"
        // affichez "colors1"

        // Copiez "colors1" dans une autre ArrayList "colors2"
        // affichez "colors2"

        // Mélangez l'ordre de vos couleurs de manière aléatoire dans "colors2"
        // affichez "colors2"

        // Inversez l'ordre de vos éléments de "colors2"
        // affichez "colors2"

        // Extrayez les 2 premières couleurs de "colors1" et affichez les

        // Échanger 2 couleurs par leur places dans "colors1"
        // affichez "colors1"

        // Videz "colors1"
        // affichez "colors1"

        // Testez si "colors1" est vide ou non

        // TODO ******* HashSet *******

        // Créez un HashSet de String "colorsSet1", ajoutez 3 couleurs (black, Red, Yellow)
        // et affichez "colorsSet1"

        // Affichez la taille de votre set

        // Convertissez votre set en un tableau
        // affichez le tableau

        // Convertissez votre set en liste
        // affichez la liste

        // Créez un autre set contenant (Black, Red)
        // affichez leur intersection

        // Videz "colorsSet1"
        // affichez "colorsSet1"

        // TODO ******* Map *******

        // Créez un Map de Integer:String "map1",
        // ajoutez 3 couleurs (1:black, 2:Red, 3:Yellow),
        // affichez "map1"

        // Affichez la taille de "map1"

        // Créez un autre Map de Integer:String, "map2" ,
        // ajoutez 3 couleurs (4:White, 5:Orange, 6:Blue)
        // affichez "map2"

        // Ajoutez toutes les valeurs de "map2" dans "map1"
        // affichez "map1"

        // Videz "map2"
        // affichez "map2"

        // Copiez le contenu de map1 en map2
        // affichez "map2"

        // Affichez les clés de "map1"

        // Affichez les valeurs de "map1"

        // Vérifiez si "map1" contient la clé 1

        // Vérifiez si "map1" contient la valeur "Red"

    }
}